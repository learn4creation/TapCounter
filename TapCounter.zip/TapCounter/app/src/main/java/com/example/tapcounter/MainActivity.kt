package com.example.tapcounter

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.pow

class MainActivity : AppCompatActivity() {

    private val sampleRate = 44100
    private lateinit var countText: TextView
    private lateinit var statusText: TextView
    private lateinit var playButton: MaterialButton

    private val tapCount = AtomicInteger(0)
    @Volatile private var listening = false
    private var audioThread: Thread? = null

    private val detector = TapDetector(sampleRate) {
        val n = tapCount.incrementAndGet()
        runOnUiThread { countText.text = n.toString() }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else Toast.makeText(this, "Microphone permission is needed to count taps", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        countText = findViewById(R.id.countText)
        statusText = findViewById(R.id.statusText)
        playButton = findViewById(R.id.playButton)
        val sensitivityBar = findViewById<SeekBar>(R.id.sensitivityBar)

        playButton.setOnClickListener {
            if (listening) stopListening() else ensurePermissionAndStart()
        }
        findViewById<MaterialButton>(R.id.resetButton).setOnClickListener {
            tapCount.set(0)
            countText.text = "0"
        }

        applySensitivity(sensitivityBar.progress)
        sensitivityBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = applySensitivity(p)
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    /** Slider 0..100 → threshold ratio 30 (least sensitive) .. 3 (most sensitive). */
    private fun applySensitivity(progress: Int) {
        detector.thresholdRatio = 30.0 * (0.1).pow(progress / 100.0)
    }

    private fun ensurePermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) startListening()
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    @SuppressLint("MissingPermission")
    private fun startListening() {
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufSize = maxOf(minBuf, 4096)

        // VOICE_RECOGNITION turns off automatic gain control / noise suppression on
        // most phones, which would otherwise flatten the sharp tap transients.
        val recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize)

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            Toast.makeText(this, "Could not open microphone", Toast.LENGTH_LONG).show()
            recorder.release()
            return
        }

        tapCount.set(0)
        countText.text = "0"
        detector.reset()
        listening = true
        playButton.text = "■  STOP"
        statusText.text = "Listening… start tapping"

        audioThread = Thread {
            val buffer = ShortArray(1024)
            recorder.startRecording()
            try {
                while (listening) {
                    val n = recorder.read(buffer, 0, buffer.size)
                    if (n > 0) detector.process(buffer, n)
                }
            } finally {
                recorder.stop()
                recorder.release()
            }
        }.apply { priority = Thread.MAX_PRIORITY; start() }
    }

    private fun stopListening() {
        listening = false
        audioThread?.join(500)
        audioThread = null
        playButton.text = "▶  PLAY"
        statusText.text = "Stopped — ${tapCount.get()} taps counted"
    }

    override fun onStop() {
        super.onStop()
        if (listening) stopListening()
    }
}
