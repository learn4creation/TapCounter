package com.example.tapcounter

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Detects sharp "tick" transients such as a table tennis ball hitting a racket.
 *
 * How it works:
 *  1. High-pass filter at 2.5 kHz (2 cascaded biquads). The ball/racket tap is a
 *     broadband click with lots of energy above 2.5 kHz, while voices, music and
 *     room hum live mostly below it.
 *  2. Split audio into short frames (256 samples ≈ 5.8 ms @ 44.1 kHz) and compute
 *     each frame's energy.
 *  3. Track the background level as the median energy of the last ~0.4 s.
 *  4. A tap is counted when a frame is [thresholdRatio]× louder than the background
 *     AND jumps sharply from the previous frame, with a short refractory period so
 *     one tap's ringing isn't counted twice.
 */
class TapDetector(
    private val sampleRate: Int,
    private val onTap: () -> Unit
) {
    /** Energy ratio over background needed to count a tap. Lower = more sensitive. */
    @Volatile var thresholdRatio: Double = 8.0

    private val frameSize = 256
    private val riseRatio = 2.5                      // frame must jump vs previous frame
    private val refractorySamples = (0.07 * sampleRate).toLong()  // 70 ms min gap
    private val warmupFrames = (0.5 * sampleRate / frameSize).toInt()
    private val historySize = (0.4 * sampleRate / frameSize).toInt()
    private val minEnergy = 1e-7                     // ignore digital silence

    // Biquad high-pass coefficients (RBJ cookbook, Q = 0.707)
    private val b0: Double; private val b1: Double; private val b2: Double
    private val a1: Double; private val a2: Double
    // Filter states for two cascaded stages
    private val x1 = DoubleArray(2); private val x2 = DoubleArray(2)
    private val y1 = DoubleArray(2); private val y2 = DoubleArray(2)

    private val history = DoubleArray(historySize)
    private val sortBuf = DoubleArray(historySize)
    private var historyCount = 0
    private var historyPos = 0

    private var frameAcc = 0.0
    private var frameFill = 0
    private var frameIndex = 0L
    private var prevEnergy = 0.0
    private var sampleCounter = 0L
    private var lastTapSample = Long.MIN_VALUE / 2

    init {
        val w0 = 2 * PI * 2500.0 / sampleRate
        val alpha = sin(w0) / (2 * 0.7071)
        val c = cos(w0)
        val a0 = 1 + alpha
        b0 = ((1 + c) / 2) / a0
        b1 = (-(1 + c)) / a0
        b2 = ((1 + c) / 2) / a0
        a1 = (-2 * c) / a0
        a2 = (1 - alpha) / a0
    }

    fun reset() {
        x1.fill(0.0); x2.fill(0.0); y1.fill(0.0); y2.fill(0.0)
        historyCount = 0; historyPos = 0
        frameAcc = 0.0; frameFill = 0; frameIndex = 0
        prevEnergy = 0.0; sampleCounter = 0
        lastTapSample = Long.MIN_VALUE / 2
    }

    fun process(buffer: ShortArray, length: Int) {
        for (i in 0 until length) {
            var s = buffer[i] / 32768.0
            for (st in 0..1) {
                val y = b0 * s + b1 * x1[st] + b2 * x2[st] - a1 * y1[st] - a2 * y2[st]
                x2[st] = x1[st]; x1[st] = s
                y2[st] = y1[st]; y1[st] = y
                s = y
            }
            frameAcc += s * s
            frameFill++
            sampleCounter++
            if (frameFill == frameSize) {
                onFrame(frameAcc / frameSize)
                frameAcc = 0.0
                frameFill = 0
            }
        }
    }

    private fun onFrame(energy: Double) {
        frameIndex++
        if (historyCount > 5 && frameIndex > warmupFrames) {
            val bg = median().coerceAtLeast(1e-12)
            val isTap = energy > thresholdRatio * bg &&
                    energy > riseRatio * prevEnergy &&
                    energy > minEnergy &&
                    sampleCounter - lastTapSample >= refractorySamples
            if (isTap) {
                lastTapSample = sampleCounter
                onTap()
            }
        }
        history[historyPos] = energy
        historyPos = (historyPos + 1) % historySize
        if (historyCount < historySize) historyCount++
        prevEnergy = energy
    }

    private fun median(): Double {
        System.arraycopy(history, 0, sortBuf, 0, historyCount)
        java.util.Arrays.sort(sortBuf, 0, historyCount)
        return sortBuf[historyCount / 2]
    }
}
